//
//  InputFormApp.swift
//  InputForm
//
//  Created by Bear Cahill on 9/15/20.
//

import SwiftUI

@main
struct InputFormApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
