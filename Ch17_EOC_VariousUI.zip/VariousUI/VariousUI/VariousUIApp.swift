//
//  VariousUIApp.swift
//  VariousUI
//
//  Created by Bear Cahill on 9/14/20.
//

import SwiftUI

@main
struct VariousUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
