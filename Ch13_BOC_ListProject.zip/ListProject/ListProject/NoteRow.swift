//
//  NoteRow.swift
//  ListProject
//
//  Created by Bear Cahill
//  Copyright © 2020 BrainwashInc. All rights reserved.
//

import SwiftUI

enum Priority : Int, Codable, CaseIterable {
    case low, medium, high
    
    static var max : Int {
        Priority.init(rawValue:
            Priority.allCases.count - 1)!.rawValue
    }
}

//MARK: ------- Model
class Note : Identifiable, Codable {
    var id = UUID().uuidString
    var text = "New Note" {
        didSet {
            self.updatedAtTime = Date()
        }
    }
    var updatedAtTime = Date()
    var priority = Priority.low {
        didSet {
            self.updatedAtTime = Date()
        }
    }
    var image = ""
    var dueDate = Date.distantFuture
    var isPastDue : Bool {
        dueDate < Date()
    }
}

//MARK: ------- View Model
class NoteViewModel : Identifiable {
    var id = UUID().uuidString
    var text = ""
    var priorityImages : [String]
    var time = ""
    var imageName = ""
    var renderingColor = Color(UIColor.label)
    
    static var dateFormatter : DateFormatter {
        let df = DateFormatter()
        df.dateStyle = .none
        df.timeStyle = .medium
        return df
    }
    
    init(model : Note) {
        text = model.text
        time = NoteViewModel.dateFormatter.string(from:
                        model.updatedAtTime)
        renderingColor = model.isPastDue ? Color.red : renderingColor
        imageName = model.image
        priorityImages = NoteViewModel.handlePriority(priority: model.priority)
    }
    
    static func handlePriority(priority : Priority) -> [String] {
        var pImages = Array(repeating: "star.circle",
                        count: priority.rawValue + 1)
        pImages += Array(repeating: "circle",
                        count: Priority.max - priority.rawValue)
        return pImages
    }

    #if DEBUG
    static func loadTestData() -> [NoteViewModel] {
        guard let url = Bundle.main.url(forResource: "Data",
                                        withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let notes = try? JSONDecoder().decode([Note].self,
                                                    from: data)
                else { return [] }
        return notes.map { NoteViewModel(model: $0) }
    }
    #endif
}

//MARK: ------- View
struct NoteRow: View {
    @Binding var noteVM : NoteViewModel
    
    var body: some View {
        HStack {
            Image(noteVM.imageName)
                .resizable()
                .frame(width: 100.0,height:100)
            VStack(alignment: .leading) {
                Text(noteVM.text)
                NotePriorityAndTime(noteVM: $noteVM)
            }
        }
    }
}

struct NoteRow_Previews: PreviewProvider {
    @State private static var items = NoteViewModel.loadTestData()

    static var previews: some View {
        List {
            ForEach(items.indices) { (noteIndex) in
                NoteRow(noteVM: self.$items[noteIndex])
            }
        }
    }
}

extension Color {
    func uiColor() -> UIColor {
        let hex = self.description
        let space = CharacterSet(charactersIn: " ")
        let trim = hex.trimmingCharacters(in: space)
        let value = hex.first != "#" ? "#\(trim)" : trim
        let values = Array(value)

        func radixValue(_ index: Int) -> CGFloat? {
            var result: CGFloat?
            if values.count > index + 1 {
                var input = "\(values[index])\(values[index + 1])"
                if values[index] == "0" {
                    input = "\(values[index + 1])"
                }
                if let val = Int(input, radix: 16) {
                    result = CGFloat(val)
                }
            }
            return result
        }
        
        var rgb = (red: CGFloat(0), green: CGFloat(0), blue: CGFloat(0), alpha: CGFloat(0))
        if let outputR = radixValue(1) { rgb.red = outputR / 255 }
        if let outputG = radixValue(3) { rgb.green = outputG / 255 }
        if let outputB = radixValue(5) { rgb.blue = outputB / 255 }
        if let outputA = radixValue(7) { rgb.alpha = outputA / 255 }
        return UIColor(red: rgb.red, green: rgb.green, blue: rgb.blue, alpha: rgb.alpha)
    }
}

let buttonHW : CGFloat = 40

class ButtonView : UIView {
    var noteVM : NoteViewModel?

    init(rect : CGRect, noteVM : NoteViewModel) {
        super.init(frame: rect)
        self.noteVM = noteVM
        configUI()
    }
    
    func configUI() {
        subviews.forEach { (btn) in
            btn.removeFromSuperview()
        }

        guard let nvm = self.noteVM else { return }
        let renderColor = nvm.renderingColor == .red ? UIColor.red : UIColor.label

        var btnRect = self.frame
        btnRect.size.width = buttonHW
        for btnIndex in 0..<3 {
            let btn = UIButton(type: .roundedRect)
            btnRect.origin.x = CGFloat(btnIndex) * buttonHW
            btn.frame = btnRect
            btn.tintColor = renderColor
            btn.tag = btnIndex
            let img = UIImage(systemName: noteVM!.priorityImages[btnIndex])
            btn.setImage(img, for: .normal)
            self.addSubview(btn)
        }
    }
    
    // needed for storyboards but we aren't using them
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

final class PriorityStarButtons : UIViewRepresentable {
    var noteVM : NoteViewModel
    
    init(noteViewModel : NoteViewModel) {
        noteVM = noteViewModel
    }
    
    func makeUIView(context: Context) -> UIView {
        let rect = CGRect(x: 0, y: 14, width: buttonHW*3, height: buttonHW)
        return ButtonView(rect: rect, noteVM: noteVM)
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {
    }
}


struct NotePriorityAndTime: View {
    @Binding var noteVM : NoteViewModel

    var body: some View {
        HStack {
            PriorityStarButtons(noteViewModel: self.noteVM)
            Spacer()
            Text(noteVM.time)
                .fontWeight(.thin)
                .foregroundColor(self.noteVM.renderingColor)
        }
    }
}
