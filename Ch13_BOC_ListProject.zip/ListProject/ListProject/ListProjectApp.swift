//
//  ListProjectApp.swift
//  ListProject
//
//  Created by Bear Cahill on 9/8/20.
//

import SwiftUI

@main
struct ListProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
