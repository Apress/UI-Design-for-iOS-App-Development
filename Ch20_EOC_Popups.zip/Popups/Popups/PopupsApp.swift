//
//  PopupsApp.swift
//  Popups
//
//  Created by Bear Cahill on 9/15/20.
//

import SwiftUI

@main
struct PopupsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
