//
//  NoteView.swift
//  ListProject
//
//  Created by Bear Q Cahill
//  Copyright © 2020 BrainwashInc. All rights reserved.
//

import SwiftUI

struct TextView: UIViewRepresentable {
    @Binding var text: String
 
    func makeUIView(context: Context) -> UITextView {
        let tv = UITextView()
        tv.delegate = context.coordinator
        return tv
    }
 
    func updateUIView(_ tvNote: UITextView, context: Context) {
        tvNote.text = text
    }

    func makeCoordinator() -> TextView.Coordinator {
        Coordinator(text: $text)
    }
    
    class Coordinator: NSObject, UITextViewDelegate {
        var text: Binding<String>
     
        init(text: Binding<String>) {
            self.text = text
        }
     
        func textViewDidChange(_ textView: UITextView) {
            text.wrappedValue = textView.text
        }
    }
}

struct NoteView : View {
    @Binding var noteVM : NoteViewModel
    
    var body: some View {
        VStack {
            NotePriorityAndTime(noteVM: noteVM)
            Spacer()
//                Text(noteVM.text)
            TextView(text: $noteVM.text)
                .border(Color.gray, width: 1)
            Spacer()
            Image(noteVM.imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
        }.padding()
    }
}

struct NoteView_Previews: PreviewProvider {
    @State static var noteVM =
        NoteViewModel.loadTestData().last!
    static var previews: some View {
        NoteView(noteVM: $noteVM)
    }
}


