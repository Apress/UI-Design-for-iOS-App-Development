//
//  SUINotesApp.swift
//  SUINotes
//
//  Created by Bear Q Cahill on 9/1/20.
//

import SwiftUI

@main
struct SUINotesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
