//
//  ListProjectApp.swift
//  ListProject
//
//  Created by Bear Q Cahill on 8/31/20.
//

import SwiftUI

@main
struct ListProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
